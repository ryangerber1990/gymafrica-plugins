<?php
/**
 * Created by IntelliJ IDEA.
 * User: ryan
 * Date: 2018/06/12
 * Time: 10:04 AM
 */
namespace Webtonic\Assemblyrequired\Api\Data;
use Magento\Framework\Api\ExtensibleDataInterface;
interface ExtensibleAssemblyDataInterface extends ExtensibleDataInterface{



    /**
     * Retrieve existing extension attributes object or create a new one.
     *
     * @return \Magento\Catalog\Api\Data\ProductExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     *
     * @param \Magento\Catalog\Api\Data\ProductExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Magento\Catalog\Api\Data\ProductExtensionInterface $extensionAttributes
    );
}