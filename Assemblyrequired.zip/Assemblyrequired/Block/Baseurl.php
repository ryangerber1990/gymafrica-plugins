<?php
/**
 * Created by IntelliJ IDEA.
 * User: ryan
 * Date: 2018/06/20
 * Time: 12:26 PM
 */
namespace Webtonic\Assemblyrequired\Block;

class Baseurl extends \Magento\Framework\View\Element\Template
{
    public function __construct
    (
        \Magento\Framework\View\Element\Template\Context $context
    )
    {
        parent::__construct($context);
    }

    public function getBaseUrl()
    {
        return parent::getBaseUrl();
    }
}