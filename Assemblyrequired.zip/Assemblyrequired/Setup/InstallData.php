<?php
/**
 * Created by IntelliJ IDEA.
 * User: ryan
 * Date: 2018/06/12
 * Time: 9:46 AM
 */
namespace Webtonic\AssemblyRequired\Setup;
use Magento\Catalog\Model\Product;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements \Magento\Framework\Setup\InstallDataInterface{


    private $eavSetupFactory;
    private $eavConfig;
    private $attributeResource;

    public function __construct(   \Magento\Eav\Setup\EavSetupFactory $eavSetupFactory,
                                   \Magento\Eav\Model\Config $eavConfig,
                                   \Magento\Customer\Model\ResourceModel\Attribute $attributeResource
    ){
        $this->eavSetupFactory = $eavSetupFactory;
        $this->eavConfig = $eavConfig;
        $this->attributeResource = $attributeResource;
    }

    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        $salesSetup = $this->salesSetupFactory->create(['resourceName' => 'sales_setup', 'setup' => $installer]);

        $salesSetup->addAttribute(Order::ENTITY, 'contact_regarding_assembly', [
            'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            'length'=> 255,
            'visible' => false,
            'nullable' => true
        ]);

        $installer->getConnection()->addColumn(
            $installer->getTable('sales_order_grid'),
            'contact_for_assembly',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => 255
            ]
        );

        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        $eavSetup->addAttribute(Product::ENTITY, 'assembly_required', [
            'Yes','No'
        ]);

        $attribute = $this->eavConfig->getAttribute(Product::ENTITY, 'assembly_required');
        $attribute->setData('used_in_forms', ['adminhtml_product','frontend_checkout']);
        $this->attributeResource->save($attribute);

        $installer->endSetup();

    }
}