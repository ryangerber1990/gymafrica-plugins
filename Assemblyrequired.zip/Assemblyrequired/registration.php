<?php
/**
 * Created by IntelliJ IDEA.
 * User: ryan
 * Date: 2018/06/04
 * Time: 3:20 PM
 */

\Magento\Framework\Component\ComponentRegistrar::register(
        \Magento\Framework\Component\ComponentRegistrar::MODULE,
        'Webtonic_Assemblyrequired',
        __DIR__
    );