<?php namespace Webtonic\Assemblyrequired\Observer;
use Magento\Framework\Event\ObserverInterface;

class Observer implements ObserverInterface
{

    protected $connector;

    public function __construct()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {

        if(isset($_SESSION['contact'])&& $_SESSION['contact'] == true) {
            $order = $observer->getEvent()->getOrder();
            $order->addStatusHistoryComment('Please contact regarding assembly')->setIsCustomerNotified(false)->setEntityName('order')->save();
        }
        unset($_SESSION['contact']);

    }

}
