<?php
namespace Webtonic\Assemblyrequired\Controller\Index;

class Assembly extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;
    protected $resultJsonFactory;
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
    {
        $this->_pageFactory = $pageFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        return parent::__construct($context);
    }

    public function execute()
    {
        $_SESSION['contact'] = null;

        $para =$this->getRequest()->getPost("assemblyrequired");
        $lock = $this->getRequest()->getPost("lock");
        if($para==true && $lock=='AssembleMe'){
        $_SESSION['contact'] = true;

        }
        else
            {
            $_SESSION['contact'] = false;
        }

       // return  $this->resultJsonFactory->create()->setData(['Checked' => 'Hello!']);
    }
}