var config = {
    'config': {
        'mixins': {
            'Magento_Checkout/js/view/shipping': {
                'Webtonic_Assemblyrequired/js/view/shipping-payment-mixin': true
            },
            'Magento_Checkout/js/view/payment': {
                'Webtonic_Assemblyrequired/js/view/shipping-payment-mixin': true
            }
        }
    }
}